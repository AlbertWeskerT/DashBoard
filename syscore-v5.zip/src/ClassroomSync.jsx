// src/ClassroomSync.jsx — SYS//CORE v5.0
// Інтеграція Google Classroom:
//   Метод A: Apps Script webhook (рекомендований, дивись README)
//   Метод B: Розумний парсер — вставляєш текст, система сама розбирає
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { RefreshCw, Link, FileText, CheckCircle, AlertTriangle, X, ExternalLink } from "lucide-react";
import { C } from "./tokens";
import { usePersist } from "./hooks";
import { Btn, Inp, Tag } from "./ui";

// ── Classroom text parser ─────────────────────────────────────────
// Парсить будь-який текст з Google Classroom (назви + дедлайни)
export function parseClassroom(raw) {
  if (!raw.trim()) return [];
  const lines = raw.split("\n").map(l => l.trim()).filter(Boolean);
  const tasks  = [];

  const MONTHS_UK = {
    "січ":1,"лют":2,"бер":3,"кві":4,"тра":5,"чер":6,
    "лип":7,"сер":8,"вер":9,"жов":10,"лис":11,"гру":12,
  };
  const MONTHS_EN = {
    jan:1,feb:2,mar:3,apr:4,may:5,jun:6,
    jul:7,aug:8,sep:9,oct:10,nov:11,dec:12,
  };

  const parseDate = (str) => {
    // "20 груд.", "Dec 20", "до 20.12", "20/12/2025", "2025-12-20"
    let m;
    // ISO / numbers: 20.12, 20/12, 20.12.2025
    if ((m = str.match(/(\d{1,2})[./](\d{1,2})(?:[./](\d{2,4}))?/))) {
      const d = parseInt(m[1]), mo = parseInt(m[2]);
      if (d >= 1 && d <= 31 && mo >= 1 && mo <= 12) {
        const y = m[3] ? (m[3].length===2 ? 2000+parseInt(m[3]) : parseInt(m[3])) : new Date().getFullYear();
        return new Date(y, mo-1, d, 23, 59).toISOString();
      }
    }
    // "20 груд" / "20 dec"
    if ((m = str.match(/(\d{1,2})\s+([а-яa-z]{3})/i))) {
      const d = parseInt(m[1]);
      const mk = m[2].toLowerCase().slice(0,3);
      const mo = MONTHS_UK[mk] || MONTHS_EN[mk];
      if (mo && d >= 1 && d <= 31)
        return new Date(new Date().getFullYear(), mo-1, d, 23, 59).toISOString();
    }
    // "груд 20" / "dec 20"
    if ((m = str.match(/([а-яa-z]{3})\s+(\d{1,2})/i))) {
      const mk = m[1].toLowerCase().slice(0,3);
      const mo = MONTHS_UK[mk] || MONTHS_EN[mk];
      const d  = parseInt(m[2]);
      if (mo && d >= 1 && d <= 31)
        return new Date(new Date().getFullYear(), mo-1, d, 23, 59).toISOString();
    }
    return null;
  };

  const SKIP = /^(google classroom|stream|classwork|people|grades|assignments?|завдання|тема|оголошення|матеріали|оцінки|posted|due|здано|очікується|відсутнє|всі категорії|no due date|без терміну|\d{1,2}:\d{2}|^\d+$)/i;

  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.length < 5 || SKIP.test(line)) { i++; continue; }

    const task = { text: line, deadline: null, source: "classroom" };

    // scan next 4 lines for deadline
    for (let j = i+1; j < Math.min(i+5, lines.length); j++) {
      const dl = lines[j];
      // "Термін здачі: ...", "Due: ...", "до ...", "Здати до ..."
      const datePart = dl
        .replace(/^(термін[:\s]*здач[іи]?|due[:\s]*date|due|до|здати до|дедлайн[:\s]*)/i, "")
        .trim();
      const parsed = parseDate(datePart) || parseDate(dl);
      if (parsed) { task.deadline = parsed; break; }
    }

    tasks.push(task);
    i++;
  }
  return tasks;
}

// ── Webhook receiver (calls Apps Script) ─────────────────────────
async function fetchFromWebhook(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  // Expected format from Apps Script:
  // [ { title: "...", dueDate: "2025-12-20T23:59:00.000Z", courseTitle: "..." }, ... ]
  return data.map(item => ({
    text: item.courseTitle ? `[${item.courseTitle}] ${item.title}` : item.title,
    deadline: item.dueDate || null,
    source: "classroom-api",
  }));
}

export default function ClassroomSync({ onImport }) {
  const [webhookUrl, setWebhookUrl] = usePersist("sc_webhook", "");
  const [pasteText,  setPasteText]  = useState("");
  const [tab,        setTab]        = useState("paste"); // paste | webhook | guide
  const [status,     setStatus]     = useState(null); // { type: ok|err, msg }
  const [loading,    setLoading]    = useState(false);
  const [preview,    setPreview]    = useState([]);
  const [showPreview, setShowPre]   = useState(false);

  const doImport = (tasks) => {
    if (!tasks.length) { setStatus({ type:"err", msg:"ЗАВДАНЬ НЕ ЗНАЙДЕНО — ПЕРЕВІР ФОРМАТ" }); return; }
    setPreview(tasks);
    setShowPre(true);
    setStatus(null);
  };

  const confirmImport = () => {
    onImport(preview);
    setStatus({ type:"ok", msg:`ІМПОРТОВАНО ${preview.length} ЗАВДАНЬ → MISSION LOG` });
    setShowPre(false); setPreview([]); setPasteText("");
    setTimeout(() => setStatus(null), 3000);
  };

  const runPaste = () => {
    const tasks = parseClassroom(pasteText);
    doImport(tasks);
  };

  const runWebhook = async () => {
    if (!webhookUrl.trim()) { setStatus({ type:"err", msg:"ВВЕДИ URL WEBHOOK" }); return; }
    setLoading(true); setStatus(null);
    try {
      const tasks = await fetchFromWebhook(webhookUrl.trim());
      doImport(tasks);
    } catch (e) {
      setStatus({ type:"err", msg:`ПОМИЛКА: ${e.message}` });
    } finally { setLoading(false); }
  };

  return (
    <div>
      {/* Tab switcher */}
      <div className="flex gap-1 mb-3 flex-wrap">
        {[
          { id:"paste",   label:"📋 ВСТАВИТИ ТЕКСТ" },
          { id:"webhook", label:"🔗 WEBHOOK API" },
          { id:"guide",   label:"📖 ЯК НАЛАШТУВАТИ" },
        ].map(t => (
          <button key={t.id} className="clip-sm mono cursor-pointer"
            onClick={() => setTab(t.id)}
            style={{
              fontSize:9, padding:"4px 10px", letterSpacing:1,
              border:`1px solid ${tab===t.id?C.green:C.border}`,
              background: tab===t.id?`${C.green}18`:"transparent",
              color: tab===t.id?C.green:C.dim, transition:"all .15s",
            }}>{t.label}</button>
        ))}
      </div>

      {/* ── Paste Tab ── */}
      {tab==="paste" && (
        <div className="flex flex-col gap-2">
          <div className="mono" style={{ color:C.dim, fontSize:10, letterSpacing:1 }}>
            Відкрий Google Classroom → скопіюй список завдань → вставь сюди:
          </div>
          <textarea className="ci clip-inp mono"
            placeholder={"Приклад:\n\nЛабораторна робота №3 — Алгоритми\nТермін здачі: 20 груд.\n\nКурсова — Мережі\nDue: Dec 25\n\nПрезентація по ОС\nдо 15.01"}
            value={pasteText}
            onChange={e => setPasteText(e.target.value)}
            rows={7}
            style={{ width:"100%" }}
            onFocus={e => e.target.style.borderColor=C.green}
            onBlur={e  => e.target.style.borderColor=C.border}/>
          <div className="flex gap-2">
            <Btn ch={<><RefreshCw size={10}/>РОЗПАРСИТИ І ІМПОРТУВАТИ</>}
              color={C.green} onClick={runPaste} disabled={!pasteText.trim()}/>
            {pasteText && <Btn ch={<><X size={10}/>CLEAR</>} color={C.dim} sm onClick={() => setPasteText("")}/>}
          </div>
        </div>
      )}

      {/* ── Webhook Tab ── */}
      {tab==="webhook" && (
        <div className="flex flex-col gap-2">
          <div className="mono" style={{ color:C.dim, fontSize:10, letterSpacing:1 }}>
            URL твого Google Apps Script Web App (дивись вкладку "ЯК НАЛАШТУВАТИ"):
          </div>
          <input className="ci clip-inp mono"
            placeholder="https://script.google.com/macros/s/ABC.../exec"
            value={webhookUrl}
            onChange={e => setWebhookUrl(e.target.value)}
            style={{ width:"100%" }}
            onFocus={e => e.target.style.borderColor=C.green}
            onBlur={e  => e.target.style.borderColor=C.border}/>
          <div className="flex gap-2 items-center">
            <Btn ch={loading ? <><RefreshCw size={10} style={{ animation:"spin 1s linear infinite" }}/>СИНХРОНІЗАЦІЯ...</> : <><RefreshCw size={10}/>SYNC CLASSROOM</>}
              color={C.green} onClick={runWebhook} disabled={loading || !webhookUrl.trim()}/>
            {webhookUrl && (
              <button onClick={() => window.open(webhookUrl, "_blank")}
                style={{ color:C.dim, background:"none", border:"none", cursor:"pointer", display:"flex", alignItems:"center", gap:3, fontSize:10 }}
                onMouseEnter={e=>e.currentTarget.style.color=C.cyan}
                onMouseLeave={e=>e.currentTarget.style.color=C.dim}>
                <ExternalLink size={10}/>ТЕСТ
              </button>
            )}
          </div>
          <div className="mono" style={{ color:C.dim2, fontSize:9, letterSpacing:1 }}>
            Дані оновлюються при кожному натисканні SYNC. URL зберігається локально.
          </div>
        </div>
      )}

      {/* ── Guide Tab ── */}
      {tab==="guide" && (
        <div className="flex flex-col gap-2" style={{ maxHeight:260, overflowY:"auto" }} className="sy">
          <div style={{ background:`${C.green}08`, border:`1px solid ${C.green}33`, padding:"10px 12px" }}>
            <div className="orb" style={{ color:C.green, fontSize:10, letterSpacing:2, marginBottom:8 }}>
              🔗 МЕТОД 1: APPS SCRIPT WEBHOOK (рекомендований)
            </div>
            <div className="mono" style={{ color:C.text, fontSize:11, lineHeight:1.7 }}>
              <b style={{ color:C.yellow }}>Крок 1.</b> Відкрий{" "}
              <a href="https://script.google.com" target="_blank" rel="noreferrer"
                style={{ color:C.cyan }}>script.google.com</a> → "Новий проект"<br/>
              <b style={{ color:C.yellow }}>Крок 2.</b> Замінити весь код на:
            </div>
            <pre style={{ background:C.bg, border:`1px solid ${C.border}`, padding:"8px 10px", marginTop:8,
              fontSize:10, color:C.cyan, overflowX:"auto", lineHeight:1.6 }}>{`function doGet() {
  var service = CourseWorkApp;
  var courses  = Classroom.Courses.list().courses || [];
  var result   = [];

  courses.forEach(function(course) {
    try {
      var works = Classroom.Courses.CourseWork
        .list(course.id, {courseWorkStates:['PUBLISHED']})
        .courseWork || [];

      works.forEach(function(work) {
        var due = null;
        if (work.dueDate) {
          var d = work.dueDate;
          due = new Date(d.year,d.month-1,d.day,23,59).toISOString();
        }
        result.push({
          title:       work.title,
          courseTitle: course.name,
          dueDate:     due,
          id:          work.id,
        });
      });
    } catch(e) {}
  });

  return ContentService
    .createTextOutput(JSON.stringify(result))
    .setMimeType(ContentService.MimeType.JSON);
}`}</pre>
            <div className="mono" style={{ color:C.text, fontSize:11, lineHeight:1.7, marginTop:8 }}>
              <b style={{ color:C.yellow }}>Крок 3.</b> Зберегти (Ctrl+S)<br/>
              <b style={{ color:C.yellow }}>Крок 4.</b> Розширення → Classroom API → увімкнути<br/>
              <b style={{ color:C.yellow }}>Крок 5.</b> Розгорнути → "Новий деплой" → Тип: "Веб-застосунок"<br/>
              &nbsp;&nbsp;→ "Виконувати як: Я" → "Доступ: Всі"<br/>
              <b style={{ color:C.yellow }}>Крок 6.</b> Скопіювати URL → вставити у вкладку WEBHOOK API
            </div>
          </div>

          <div style={{ background:`${C.cyan}08`, border:`1px solid ${C.cyan}33`, padding:"10px 12px", marginTop:4 }}>
            <div className="orb" style={{ color:C.cyan, fontSize:10, letterSpacing:2, marginBottom:8 }}>
              📋 МЕТОД 2: РУЧНИЙ ПАРСЕР (без налаштування)
            </div>
            <div className="mono" style={{ color:C.text, fontSize:11, lineHeight:1.7 }}>
              1. Відкрий Google Classroom у браузері<br/>
              2. Перейди у розділ "Завдання" ("Classwork")<br/>
              3. Виділи весь текст на сторінці (Ctrl+A)<br/>
              4. Скопіюй (Ctrl+C)<br/>
              5. Вставши у вкладку "ВСТАВИТИ ТЕКСТ"<br/>
              6. Натисни РОЗПАРСИТИ — система сама знайде<br/>
              &nbsp;&nbsp;назви завдань і дати дедлайнів<br/><br/>
              <span style={{ color:C.yellow }}>Підтримувані формати дат:</span><br/>
              "20 груд.", "Dec 20", "до 20.12",<br/>
              "20/12/2025", "2025-12-20", "Термін: 20.12"
            </div>
          </div>
        </div>
      )}

      {/* Status */}
      <AnimatePresence>
        {status && (
          <motion.div initial={{ opacity:0,y:-5 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0 }}
            className="mono" style={{
              marginTop:8, fontSize:10, letterSpacing:1,
              color: status.type==="ok" ? C.green : C.pink,
              padding:"6px 10px",
              border:`1px solid ${status.type==="ok" ? C.green : C.pink}44`,
              background:`${status.type==="ok" ? C.green : C.pink}0a`,
              display:"flex", alignItems:"center", gap:6,
            }}>
            {status.type==="ok" ? <CheckCircle size={11}/> : <AlertTriangle size={11}/>}
            {status.msg}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Preview modal */}
      <AnimatePresence>
        {showPreview && (
          <motion.div initial={{ opacity:0,y:10 }} animate={{ opacity:1,y:0 }} exit={{ opacity:0,y:10 }}
            style={{ marginTop:10, border:`1px solid ${C.green}66`, background:`${C.green}07`, padding:"10px 12px" }}>
            <div className="flex items-center justify-between mb-2">
              <span className="orb" style={{ color:C.green, fontSize:10, letterSpacing:2 }}>
                ЗНАЙДЕНО {preview.length} ЗАВДАНЬ — ПІДТВЕРДИТИ?
              </span>
              <Btn ch={<><X size={10}/>CANCEL</>} color={C.dim} sm onClick={() => { setShowPre(false); setPreview([]); }}/>
            </div>
            <div className="sy" style={{ maxHeight:160 }}>
              {preview.map((t,i) => (
                <div key={i} className="import-in flex items-start gap-2 py-1"
                  style={{ borderBottom:`1px solid ${C.gray2}`, fontSize:11 }}>
                  <span style={{ color:C.green, flexShrink:0 }}>→</span>
                  <span style={{ color:C.text, flex:1 }}>{t.text}</span>
                  {t.deadline && (
                    <span style={{ color:C.yellow, fontSize:10, flexShrink:0 }}>
                      {new Date(t.deadline).toLocaleDateString("uk",{day:"2-digit",month:"short"})}
                    </span>
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-2 mt-2">
              <Btn ch={<><CheckCircle size={10}/>ІМПОРТУВАТИ ВСЕ</>} color={C.green} onClick={confirmImport}/>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
