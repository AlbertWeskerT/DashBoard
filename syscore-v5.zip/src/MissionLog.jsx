// src/MissionLog.jsx — SYS//CORE v5.0
import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ClipboardList, Plus, Check, Pencil, Trash2, X, Save, Clock, Flag, Filter } from "lucide-react";
import { C, PRIO, PRIO_CYCLE, EXP } from "./tokens";
import { usePersist } from "./hooks";
import { Panel, Btn, Inp, Tag, IBtn, SecLabel } from "./ui";

const DEF = [
  { id:1, text:"Здати лабораторну з БД",       done:false, priority:"high", deadline:null, note:"" },
  { id:2, text:"Підготувати презентацію по ОС", done:false, priority:"med",  deadline:null, note:"" },
  { id:3, text:"Прочитати розділ 7 з мереж",   done:false, priority:"low",  deadline:null, note:"" },
  { id:4, text:"Вивчити JOIN-запити в SQL",     done:false, priority:"med",  deadline:null, note:"" },
];
let tid = 500;

function isUrgent(deadline) {
  if (!deadline) return false;
  const diff = new Date(deadline) - Date.now();
  return diff > 0 && diff < 86400000;
}

function isOverdue(deadline) {
  if (!deadline) return false;
  return new Date(deadline) < new Date();
}

function DeadlineLabel({ deadline }) {
  if (!deadline) return null;
  const urgent  = isUrgent(deadline);
  const overdue = isOverdue(deadline);
  const d       = new Date(deadline);
  const label   = d.toLocaleDateString("uk", { day:"2-digit", month:"short" });
  return (
    <span className={`mono flex items-center gap-1 ${urgent ? "dl-urgent" : ""}`} style={{
      fontSize:9, flexShrink:0,
      color: overdue ? C.red : urgent ? C.yellow : C.dim,
    }}>
      <Clock size={8}/>
      {overdue ? "ПРОСТРОЧЕНО " : ""}{label}
    </span>
  );
}

function TaskRow({ task, onToggle, onEdit, onDelete, dying }) {
  return (
    <div className={`tr${dying ? " evap" : ""}`}
      style={{ borderBottom:`1px solid ${C.gray2}`, position:"relative",
        boxShadow: isUrgent(task.deadline)&&!task.done ? `inset 3px 0 0 ${C.yellow}` : undefined }}>
      <div className="flex items-start gap-2.5 py-2 -mx-4 px-4" style={{ minHeight:36 }}>
        <input type="checkbox" className="cb mt-0.5" checked={task.done} onChange={() => onToggle(task.id)}/>

        {/* Priority dot — clickable to cycle */}
        <button onClick={() => onEdit(task.id, { priority: PRIO_CYCLE[task.priority] })}
          title={PRIO[task.priority]?.label}
          style={{ width:8,height:8,borderRadius:"50%",flexShrink:0,marginTop:5,
            background:PRIO[task.priority]?.color,border:"none",cursor:"pointer",
            boxShadow:`0 0 6px ${PRIO[task.priority]?.color}` }}/>

        <div style={{ flex:1, minWidth:0 }}>
          <div className="mono" style={{
            fontSize:12, color:task.done?C.dim:C.text,
            textDecoration:task.done?"line-through":"none", transition:"color .3s",
          }}>{task.text}</div>
          {task.note && !task.done && (
            <div className="mono" style={{ fontSize:10, color:C.dim, marginTop:2, letterSpacing:.5 }}>
              // {task.note}
            </div>
          )}
        </div>

        <div className="flex items-center gap-1.5 flex-shrink-0">
          <DeadlineLabel deadline={task.deadline}/>
          {task.done && <Tag label="DONE" color={C.green}/>}
          <div className="ta flex gap-1">
            <IBtn Icon={Pencil}  hover={C.cyan}   onClick={() => onEdit(task.id, null)}/>
            <IBtn Icon={Trash2}  hover={C.pink}   onClick={() => onDelete(task.id)}/>
          </div>
        </div>
      </div>
    </div>
  );
}

function TaskEditForm({ task, onSave, onCancel }) {
  const [text, setText] = useState(task.text);
  const [note, setNote] = useState(task.note || "");
  const [dl,   setDl]   = useState(task.deadline ? new Date(task.deadline).toISOString().slice(0,10) : "");
  const [prio, setPrio] = useState(task.priority);

  return (
    <div className="py-2 -mx-4 px-4 flex flex-col gap-2"
      style={{ background:`${C.cyan}07`, borderBottom:`1px solid ${C.gray2}` }}>
      <Inp val={text} set={setText} ph="Назва завдання" style={{ width:"100%" }}/>
      <Inp val={note} set={setNote} ph="// Нотатка (необов'язково)" style={{ width:"100%" }}/>
      <div className="flex gap-2 items-center flex-wrap">
        <span className="mono" style={{ color:C.dim, fontSize:10 }}>Дедлайн:</span>
        <input type="date" value={dl} onChange={e=>setDl(e.target.value)}/>
        <span className="mono" style={{ color:C.dim, fontSize:10 }}>Пріоритет:</span>
        <div className="flex gap-1">
          {Object.entries(PRIO).map(([k,v]) => (
            <button key={k} onClick={()=>setPrio(k)} title={v.label}
              style={{ width:12,height:12,borderRadius:"50%",background:v.color,
                border:prio===k?"2px solid white":"2px solid transparent",
                cursor:"pointer",boxShadow:prio===k?`0 0 8px ${v.color}`:undefined }}/>
          ))}
        </div>
      </div>
      <div className="flex gap-2">
        <Btn ch={<><Save size={10}/>ЗБЕРЕГТИ</>} color={C.cyan}
          onClick={() => onSave({ text:text.trim()||task.text, note, priority:prio, deadline:dl?new Date(dl+"T23:59:00").toISOString():null })}/>
        <Btn ch={<><X size={10}/>СКАСУВАТИ</>} color={C.dim} sm onClick={onCancel}/>
      </div>
    </div>
  );
}

export default function MissionLog({ onExp, importedTasks }) {
  const [tasks,  setTasks] = usePersist("sc_tasks5", DEF);
  const [dying,  setDying] = useState(new Set());
  const [editId, setEditId]= useState(null);
  const [input,  setInput] = useState("");
  const [note,   setNote]  = useState("");
  const [dl,     setDl]    = useState("");
  const [prio,   setPrio]  = useState("med");
  const [filter, setFilter]= useState("active");
  const [showAdd,setShowAdd]=useState(false);
  const impRef = useRef(null);

  // Consume imported tasks from Classroom
  useEffect(() => {
    if (!importedTasks || importedTasks === impRef.current || !importedTasks.length) return;
    impRef.current = importedTasks;
    setTasks(prev => {
      const existing = new Set(prev.map(t => t.text.toLowerCase()));
      const fresh = importedTasks
        .filter(t => !existing.has(t.text.toLowerCase()))
        .map(t => ({ id:tid++, text:t.text, done:false, priority:"med", deadline:t.deadline||null, note:"" }));
      if (fresh.length > 0) onExp(fresh.length * EXP.import);
      return [...prev, ...fresh];
    });
  }, [importedTasks]);

  const evaporate = (id, cb) => {
    setDying(p => new Set([...p, id]));
    setTimeout(() => {
      cb();
      setDying(p => { const n=new Set(p); n.delete(id); return n; });
    }, 620);
  };

  const toggle = id => {
    const t = tasks.find(x=>x.id===id);
    if (!t) return;
    if (!t.done) {
      evaporate(id, () => {
        setTasks(p=>p.map(x=>x.id===id?{...x,done:true}:x));
        onExp(EXP.task);
      });
    } else {
      setTasks(p=>p.map(x=>x.id===id?{...x,done:false}:x));
    }
  };

  const remove = id => evaporate(id, () => setTasks(p=>p.filter(x=>x.id!==id)));

  const editField = (id, patch) => {
    if (patch) { setTasks(p=>p.map(x=>x.id===id?{...x,...patch}:x)); }
    else { setEditId(id); }
  };

  const saveEdit = (id, data) => {
    setTasks(p=>p.map(x=>x.id===id?{...x,...data}:x));
    setEditId(null);
  };

  const addTask = () => {
    if (!input.trim()) return;
    const deadline = dl ? new Date(dl+"T23:59:00").toISOString() : null;
    setTasks(p=>[...p,{ id:tid++, text:input.trim(), done:false, priority:prio, deadline, note }]);
    setInput(""); setNote(""); setDl("");
    setShowAdd(false);
  };

  // Sorting + filtering
  const visible = tasks
    .filter(t => {
      if (filter==="active") return !t.done;
      if (filter==="done")   return t.done;
      if (filter==="urgent") return isUrgent(t.deadline) && !t.done;
      return true;
    })
    .sort((a,b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      const ua = isUrgent(a.deadline) || isOverdue(a.deadline) ? 0 : 1;
      const ub = isUrgent(b.deadline) || isOverdue(b.deadline) ? 0 : 1;
      if (ua !== ub) return ua - ub;
      const pc = { high:0, med:1, low:2 };
      return (pc[a.priority]||1) - (pc[b.priority]||1);
    });

  const doneCount   = tasks.filter(t=>t.done).length;
  const urgentCount = tasks.filter(t=>isUrgent(t.deadline)&&!t.done).length;
  const overdueCount= tasks.filter(t=>isOverdue(t.deadline)&&!t.done).length;

  return (
    <Panel icon={ClipboardList} title="MISSION LOG"
      sub={`${doneCount}/${tasks.length}`} scrollH={420}>

      {/* Filter bar */}
      <div className="flex gap-1 mb-3 flex-wrap items-center">
        {[
          { id:"active", label:"ACTIVE" },
          { id:"all",    label:"ALL"    },
          { id:"done",   label:"DONE"   },
          { id:"urgent", label:`⚠ URGENT${urgentCount>0?` (${urgentCount})`:""}` },
        ].map(f => (
          <button key={f.id} className="clip-sm mono cursor-pointer"
            onClick={() => setFilter(f.id)}
            style={{
              fontSize:9, padding:"3px 10px", letterSpacing:1,
              border:`1px solid ${filter===f.id?C.cyan:C.border}`,
              background: filter===f.id?`${C.cyan}18`:"transparent",
              color: filter===f.id?C.cyan:C.dim, transition:"all .15s",
            }}>{f.label}</button>
        ))}
        {overdueCount > 0 && (
          <span className="mono ml-auto" style={{ color:C.red, fontSize:9 }}>
            🔴 {overdueCount} ПРОСТРОЧЕНО
          </span>
        )}
      </div>

      {/* Task list */}
      <div className="sy" style={{ maxHeight:280 }}>
        <AnimatePresence mode="popLayout">
          {visible.length === 0 && (
            <motion.div key="empty" initial={{ opacity:0 }} animate={{ opacity:.5 }}
              className="mono" style={{ color:C.dim, fontSize:11, textAlign:"center", padding:"18px 0", letterSpacing:2 }}>
              // {filter==="done"?"НЕМАЄ ВИКОНАНИХ":"ВСЕ ВИКОНАНО ✓"}
            </motion.div>
          )}
          {visible.map(t => (
            <motion.div key={t.id} layout
              initial={{ opacity:0,y:-8 }} animate={{ opacity:1,y:0 }}
              exit={{ opacity:0,scale:.9, transition:{duration:.15} }}>
              {editId===t.id ? (
                <TaskEditForm task={t}
                  onSave={data => saveEdit(t.id, data)}
                  onCancel={() => setEditId(null)}/>
              ) : (
                <TaskRow task={t} dying={dying.has(t.id)}
                  onToggle={toggle} onEdit={editField} onDelete={remove}/>
              )}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Add task form */}
      <div className="mt-3">
        <button className="clip-sm mono cursor-pointer"
          onClick={() => setShowAdd(v=>!v)}
          style={{ fontSize:10, padding:"4px 12px", letterSpacing:1,
            border:`1px solid ${C.yellow}`, background:showAdd?`${C.yellow}18`:"transparent",
            color:C.yellow, display:"inline-flex", alignItems:"center", gap:4, transition:"all .15s" }}>
          {showAdd?<X size={10}/>:<Plus size={10}/>}
          {showAdd?"СКАСУВАТИ":"+ НОВА МІСІЯ"}
        </button>

        <AnimatePresence>
          {showAdd && (
            <motion.div initial={{ opacity:0,height:0 }} animate={{ opacity:1,height:"auto" }} exit={{ opacity:0,height:0 }} style={{ overflow:"hidden", marginTop:8 }}>
              <div className="flex flex-col gap-2 p-3" style={{ border:`1px solid ${C.yellow}44`, background:`${C.yellow}06` }}>
                <Inp val={input} set={setInput} ph="НАЗВА ЗАВДАННЯ..."
                  onKey={e=>e.key==="Enter"&&addTask()} style={{ width:"100%" }}/>
                <Inp val={note}  set={setNote}  ph="// Нотатка..." style={{ width:"100%" }}/>
                <div className="flex gap-3 items-center flex-wrap">
                  <div className="flex items-center gap-2">
                    <span className="mono" style={{ color:C.dim, fontSize:10 }}>Дедлайн:</span>
                    <input type="date" value={dl} onChange={e=>setDl(e.target.value)}/>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="mono" style={{ color:C.dim, fontSize:10 }}>Пріоритет:</span>
                    <div className="flex gap-1">
                      {Object.entries(PRIO).map(([k,v]) => (
                        <button key={k} onClick={()=>setPrio(k)} title={v.label}
                          style={{ width:12,height:12,borderRadius:"50%",background:v.color,
                            border:prio===k?"2px solid white":"2px solid transparent",
                            cursor:"pointer",boxShadow:prio===k?`0 0 8px ${v.color}`:undefined }}/>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Btn ch={<><Plus size={10}/>ДОДАТИ МІСІЮ</>} color={C.yellow} onClick={addTask} disabled={!input.trim()}/>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </Panel>
  );
}
